<div class="tc-wrapper-developer">
    <div class="row">
		<?php
		do_action( 'thim_core_for_developers_before_boxes' );
		do_action( 'thim_core_for_developers_after_boxes' );
		?>
    </div>
</div>
