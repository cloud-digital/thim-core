<?php

?>
<div class="tc-modal md-modal md-effect-16" id="tc-mega-menu-how-to">
    <div class="md-content">
        <h3 class="title">How to use Thim Mega Menu?<span class="close"></span></h3>

        <div class="main text-center">
            <iframe src="https://www.youtube.com/embed/3Pis9jBder8" width="100%" height="400" frameborder="0" allowfullscreen></iframe>
        </div>
    </div>
</div>
<div class="md-overlay"></div>
